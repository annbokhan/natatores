<div class="clear"></div>

<?php wp_footer(); ?>


<footer class="breeze-footer">
    <div class="container space-2">
        <div class="row justify-content-md-between">
            <div class="col-md-3 col-sm-3 col-xs-12 ">

                <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/logo.png')" alt="">
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12 ">
                <h3 class="text-white mb-3 title-menu-footer">Natatores</h3>

                <!-- List Group -->
                <div class="list-group list-group-flush list-group-transparent">
                    Экспедиционная яхта
                </div>
             </div>
            <div class="col-md-3 col-sm-3 col-xs-12 ">
                <h3 class=" text-white mb-3 title-menu-footer">Меню</h3>

                <!-- List Group -->
                <div class="list-group list-group-flush list-group-transparent menu-footer-box">

                    <?php wp_nav_menu(array('theme_location' => 'footer-basic')); ?>


                </div>
                <!-- End List Group -->
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <h3 class=" text-white mb-3  title-menu-footer">Контакты</h3>
                <div class="contacts-links">
                    Email:<a href="mailto:ihamste@gmail.com"> gmail.com</a><br>
                    Phone:<a href="tel:+380970603036"> +811111111111</a>
                </div>
                <!-- List -->
                <div class="list-group list-group-social list-group-flush list-group-transparent">


            <span class="eltd-icon-shortcode normal" data-hover-color="#c9a482" data-color="#797979">
                    <a href="http://instagram.com/natatores2020" target="_self">
                           <span aria-hidden="true"
                                 class="eltd-icon-font-elegant social_instagram eltd-icon-element"></span>
                    </a>
            </span>
                    <span class="eltd-icon-shortcode normal" data-hover-color="#c9a482" data-color="#797979">
                    <a href="#" target="_self">
                        <span aria-hidden="true" class="eltd-icon-font-elegant social_youtube eltd-icon-element"></span>
                    </a>
            </span>
                    <span class="eltd-icon-shortcode normal" data-hover-color="#c9a482" data-color="#797979">
                    <a href="https://www.facebook.com/EkstremalnaaKomandaNatatores" target="_self">
                         <span aria-hidden="true"
                               class="eltd-icon-font-elegant social_facebook eltd-icon-element"></span>
                    </a>
            </span>
                </div>
                <!-- End List -->
            </div>
        </div>
    </div>
</footer>
<aside id="sidebarContent" class="u-sidebar u-unfold--css-animation u-unfold--hidden"
       aria-labelledby="sidebarNavToggler">
    <div class="u-sidebar__scroller">
        <div class="u-sidebar__container">
            <div class="u-sidebar--panel__footer-offset">

            </div>

            <!-- Footer -->

            <!-- End Footer -->
        </div>
    </div>
</aside>

</div>

<script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>

<!--JS Global Compulsory-->
<script type="text/javascript"
        src="<?php echo get_template_directory_uri() ?>/assets/vendor/jquery/jquery.min.js"></script>
 <script type="text/javascript"
        src="<?php echo get_template_directory_uri() ?>/assets/vendor/popper.js/dist/popper.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/eka.js"></script>
<script type="text/javascript"><?php echo get_template_directory_uri() ?>/assets/vendor/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/slick/slick.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/wow.min.js"></script>

<script>
    new WOW().init();
</script>
<script type="text/javascript" src="
<?php echo get_template_directory_uri(); ?>/assets/js/bootstrap.js"></script>

<script type="text/javascript">

    $(document).ready(function () {
        $('.slide1').slick({
            // setting-name:setting - value
        });
    });
    $(document).ready(function(){
        $('.slick_1').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 1,
            adaptiveHeight: true
        });
    });
    $(document).ready(function(){
        $('.slick_9').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 3,
            slidesToScroll: 1,
            adaptiveHeight: true
        });
    });

    $(document).ready(function(){
        $('.slick_2').slick({
            dots: true,

        });
    });
    $(document).ready(function(){
        $('.slick_111').slick({
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 3

        });
    });

</script>
</body>
</html>