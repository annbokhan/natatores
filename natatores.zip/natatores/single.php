<?php get_header(); ?>
    <div id="content" role="main">
        <?php if (have_posts()) : while (have_posts()) :
        the_post(); ?>
        <section class="post-page-top" >

            <div class="container">
                <div class="cover-container w-100 h-100 p-3 mx-auto align-items-center row">
                    <main role="main" class="inner cover text-center">

                            <?php if (is_singular()) {
                                echo '<h1 class="entry-title">';
                            } else {
                                echo '<h2 class="entry-title">';
                            } ?><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"
                                   rel="bookmark"><?php the_title(); ?></a><?php if (is_singular()) {
                                echo '</h1>';
                            } else {
                                echo '</h2>';
                            } ?>
<!--                            --><?php //edit_post_link(); ?>
<!--                            --><?php //if (!is_search()) get_template_part('entry', 'meta'); ?>

                    </main>
                </div>
            </div>
            <img src="<?php echo get_template_directory_uri(); ?>/img/purple_top_divider.png" alt="" class="img-bg-section-bottom">
        </section>

        <section class="single-cnt-post">
            <div class="container">


                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                    <?php get_template_part('entry', (is_archive() || is_search() ? 'summary' : 'content')); ?>
                    <?php if (!is_search()) get_template_part('entry-footer'); ?>
                </article>
                <?php if (!post_password_required()) comments_template('', true); ?>
                <?php endwhile;
                endif; ?>
                <footer class="footer">
                    <?php get_template_part('nav', 'below-single'); ?>
                </footer>
            </div>

        </section>
    </div>

    <!--    <section id="content" role="main">-->
    <!--        --><?php //if (have_posts()) : while (have_posts()) : the_post(); ?>
    <!--            --><?php //get_template_part('entry'); ?>
    <!--            --><?php //if (!post_password_required()) comments_template('', true); ?>
    <!--        --><?php //endwhile; endif; ?>
    <!--        <footer class="footer">-->
    <!--            --><?php //get_template_part('nav', 'below-single'); ?>
    <!--        </footer>-->
    <!--    </section>-->

<?php //get_sidebar(); ?>
<?php get_footer(); ?>