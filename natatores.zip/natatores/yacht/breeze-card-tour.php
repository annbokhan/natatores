<div class="col-md-6 col-sm-12">
    <div class="tour-details-card">

        <article>
            <div class="row">
                <div class="col-md-5">
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg" alt=""
                             class="newsPreview__image">
                    </a>
                </div>
                <div class="col-md-7">
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                  <span class="cat-links">
<!--                     --><?php //the_category(' ', '', ''); ?>
                  </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <i class="fas fa-map-marker-alt"></i>
                            <h4 class="name-card">Ялта - Гурзуф</h4>

                        </a>
                        <div class="newsList__text">
                            <!--                    <div class="date">13.12.2018 - 03.03.2019</div>-->
                            <div class="text">
                                возможны остановки напротив Гурзуфа, в лазурной бухте для купания, рыбалки
                            </div>

                            <span class="price">
<!--                        $230 /-->
                        <span>3-4 часа</span>
                    </span>

                        </div>
                        <!--                        <div class="read-more-btn-wrap">-->
                        <!--                            <a href="#" class="read-more-btn-article">-->
                        <!--                                оставить заявку-->
                        <!--                            </a>-->
                        <!--                        </div>-->
                    </div>

                </div>
            </div>
        </article>

    </div>

</div>
<div class="col-md-6 col-sm-12">
    <div class="tour-details-card">

        <article>
            <div class="row">
                <div class="col-md-5">
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg" alt=""
                             class="newsPreview__image">
                    </a>
                </div>
                <div class="col-md-7">
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                  <span class="cat-links">
<!--                     --><?php //the_category(' ', '', ''); ?>
                  </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <i class="fas fa-map-marker-alt"></i>
                            <h4 class="name-card">Ялта - Балаклава</h4>

                        </a>
                        <div class="newsList__text">
                            <div class="date">Ялта – Гаспра – Алупка – бухта Ласпи – мыс Айя – Балаклава- мыс Фиолент
                            </div>
                            <div class="text">
                                <br>
                                Продолжительность - 2 дня/ 1 ночь.<br>
                                <!--                                Посадка – в 9.00<br>-->
                                <!--                                Возвращение – в 19.00 следующего дня<br>-->
                            </div>

                            <span class="price">
<!--                        $230 /-->
                        <span>8 часа</span>
                    </span>

                        </div>
                        <!--                        <div class="read-more-btn-wrap">-->
                        <!--                            <a href="#" class="read-more-btn-article">-->
                        <!--                                оставить заявку-->
                        <!--                            </a>-->
                        <!--                        </div>-->
                    </div>

                </div>
            </div>
        </article>

    </div>

</div>
<div class="col-md-6 col-sm-12">
    <div class="tour-details-card">

        <article>
            <div class="row">
                <div class="col-md-5">
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg" alt=""
                             class="newsPreview__image">
                    </a>
                </div>
                <div class="col-md-7">
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                  <span class="cat-links">
<!--                     --><?php //the_category(' ', '', ''); ?>
                  </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <i class="fas fa-map-marker-alt"></i>
                            <h4 class="name-card">Ялта - Новый Свет</h4>

                        </a>
                        <div class="newsList__text">
                            <div class="date">
                                Ялта – Гурзуф – Партенит – Алушта – Малореченское – Новый Свет
                            </div>
                            <div class="text">
                                Посадка – в 9.00<br>
                                Возвращение – в 19.00 следующего дня
                            </div>

                            <span class="price">
                        2 дня (1 ночь) /
                        <span>10 часов хода</span>
                    </span>

                        </div>
                        <!--                        <div class="read-more-btn-wrap">-->
                        <!--                            <a href="#" class="read-more-btn-article">-->
                        <!--                                оставить заявку-->
                        <!--                            </a>-->
                        <!--                        </div>-->
                    </div>

                </div>
            </div>
        </article>

    </div>

</div>
<div class="col-md-6 col-sm-12">
    <div class="tour-details-card">

        <article>
            <div class="row">
                <div class="col-md-5">
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg" alt=""
                             class="newsPreview__image">
                    </a>
                </div>
                <div class="col-md-7">
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                  <span class="cat-links">
<!--                     --><?php //the_category(' ', '', ''); ?>
                  </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <i class="fas fa-map-marker-alt"></i>
                            <h4 class="name-card">Ялта-Ласточкино гнездо</h4>

                        </a>
                        <div class="newsList__text">
                            <div class="date">Ялта - Ливадия - Ореанда - Гаспра</div>
                            <div class="text">

                                Западное побережье Ялты. Ливадийский дворец, храм "Покрова Пресвятой Богородицы" и
                                "Святого
                                Архистратинга Михаила"<br>
                                Скала Мачтовая со скрытым гротом, в котором археологи обнаружили стоянку
                                первобытного человека. Скала "Крестовая", "Парус".

                            </div>

                            <span class="price">

                        <span>2 часа</span> хода
                    </span>

                        </div>
                        <!--                        <div class="read-more-btn-wrap">-->
                        <!--                            <a href="#" class="read-more-btn-article">-->
                        <!--                                оставить заявку-->
                        <!--                            </a>-->
                        <!--                        </div>-->
                    </div>

                </div>
            </div>
        </article>

    </div>

</div>


