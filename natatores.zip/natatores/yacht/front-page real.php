<?php
/**
 * Template Name: silver breeze front page
 */

get_header(); ?>


    <section class="vc_section vc_custom_1545783735033 services-section">
        <div class="ltx-overlay-divider"></div>
        <div class="container">
            <div class="item-text-box">
                <div class="title-block-dec">
                    <div class="subtitle">What we do</div>
                    <h2>Предлагаем для Вас</h2>
                </div>
                <p>Integer sagittis nisi nec tortor fermentum aliquet. Integer non neque tempor, porttitor lorem id,
                    commodo
                    nulla. Nullam sed ultricies erat, nec euismod metus. Morbi porttitor sapien vitae leo scelerisque
                    consequat.</p>
            </div>
            <div class="item-box-card services-sc ">
                <?php get_template_part('yacht/entery-card-blog'); ?>
            </div>

    </section>

    <section class="about-club">
        <div class="container">
            <div class="item-text-box">
                <!--                <div class="title-block-dec">-->
                <!--                    <div class="subtitle">About club</div>-->
                <!--                    <h2>About yacht club</h2>-->
                <!--                </div>-->

            </div>
            <div class="counter-numbers">
                <div class="row">
                    <div class="col-md-4 item-numbers">
                        <div class="a-number">5</div>
                        <h3>Стран</h3>
                        <p>
                            Integer sagittis nisi nec tortor fermentum aliquet. Integer non neque. Nullam sed
                            ultricies.</p>
                    </div>
                    <div class="col-md-4 item-numbers">
                        <div class="a-number">52000</div>
                        <h3>Морских миль</h3>
                        <p>Integer sagittis nisi nec tortor fermentum aliquet. Integer non neque. Nullam sed
                            ultricies.</p>
                    </div>

                    <div class="col-md-4 item-numbers">
                        <div class="a-number">1570</div>
                        <h3>Счастливых гостей</h3>
                        <p>возможно ещё одна интересная цифра</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="watch-video">
        <div class="container">
            <div class="video-box">
                <div class="row">
                    <div class="col-md-4 col-sm-12">
                        <div class="item-text-box">
                            <div class="title-block-dec">
                                <div class="subtitle">Media</div>
                                <h2>Watch our video</h2>
                            </div>
                            <p>
                                Natatores – общее латинское название плавающих птиц. А ведь известно: как ты яхту
                                назовешь, так она и поплывет. С таким именем она не плывет – летит по волнам, расправляя
                                свои паруса-крылья. Птица, скользящая по волнам.<br><br>

                                И команда, путешествующая на яхте, ей под стать. Экстремальная команда Natatores
                                объединяет людей, которые не представляют свою жизнь без приключений, драйва и
                                адреналина. Это парашютисты, дайверы и яхтсмены в одном лице. Нам и неба мало, и море по
                                колено. Если ты любишь экстремальный спорт, путешествия, море и адреналин, тебе у нас
                                понравится!<br><br>

                                Стань членом команды Natatores, отрасти крылья!
                            </p>
                        </div>
                    </div>
                    <div class="col-md-8 col-sm-12 block-frame">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/TIx0rOtnVhk?controls=0"
                                frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen class="video-frame"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="active-servises">

                <div class="item-text-box">
                    <div class="title-block-dec">
                        <div class="subtitle">What we do</div>
                        <h2 style=" font-size: 24px;">Передвижной мобильный центр экстремальных видов спорта</h2>
                    </div>
                    <p>Яхта спроектирована экстрималами для таких же любителей активного отдыха и острых ощущений<br>
                        Трехместный гидроцикл Sea-Doo Wake Pro 215 — это буксировщик вейкбордистов или воднолыжника.<br>
                        Виндсерфинговая доска с парусом и мачтой, доски для вейка и для кайта, два набора экипировки для
                        дайвинга.<br>

                        Большой ассортимент водных буксируемых игрушек.<br>

                        Наполнение ангара может быть индивидуальным, готовы принимать гостей со своим оборудованием.
                    </p>
                </div>

            </div>

        </div>
    </section>
    <!--div    <section class="yacht-list">-->
    <!--        <div class="container">-->
    <!--            <div class="item-text-box">-->
    <!--                <div class="title-block-dec">-->
    <!--                    <div class="subtitle">Media</div>-->
    <!--                    <h2> Watch our video</h2>-->
    <!--                </div>-->
    <!--                <p>-->
    <!--                    Suspendisse a ante sit amet magna volutpat faucibus sit amet sit amet erat. Nunc ante diam,-->
    <!--                    tristique quis elementum in, congue quis metus. Duis sit amet odio non tortor bibendum volutpat.-->
    <!--                    Aliquam ac posuere erat.-->
    <!--                </p>-->
    <!--            </div>-->
    <!--            <div class="row">-->
    <!--                <div class="col-md-4 col-sm-12">--><?php //get_template_part('yacht/breeze-card-yacht'); ?><!--</div>-->
    <!--                <div class="col-md-4 col-sm-12">--><?php //get_template_part('yacht/breeze-card-yacht'); ?><!--</div>-->
    <!--                <div class="col-md-4 col-sm-12">--><?php //get_template_part('yacht/breeze-card-yacht'); ?><!--</div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </section>-->

    <section class="tour-yacht-list">
        <div class="container">
            <div class="item-text-box">
                <div class="title-block-dec">
                    <div class="subtitle">Travel with us</div>
                    <h2>Варианты маршрутов вдоль берега</h2>
                </div>
                <p>
                    Морские экскурсии – шанс взглянуть на город по-новому, так как с моря выглядит совершенно иначе.<br>
                    Для сравнения длительности и дальности поездки мы привели несколько примеров локаций.<br>
                    Предлагаем выбрать маршрут, в любом направлении, на выбранное время. Все детали обсуждаются с капитаном.
                </p>
            </div>
            <div class="row">
                <?php get_template_part('yacht/breeze-card-tour'); ?>

                <!--                <div class="col-md-6 col-sm-12">--><?php //get_template_part('yacht/breeze-card-tour'); ?><!--</div>-->
                <!--                <div class="col-md-6 col-sm-12">--><?php //get_template_part('yacht/breeze-card-tour'); ?><!--</div>-->
                <!--                <div class="col-md-6 col-sm-12">--><?php //get_template_part('yacht/breeze-card-tour'); ?><!--</div>-->
            </div>
        </div>
    </section>

    <section class="br-benefit">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-12 br-benefit_item">
                    <div class="item-text-box">
                        <div class="title-block-dec">
                            <div class="subtitle">Natatores</div>
                            <h2>О Яхте</h2>
                        </div>
                    </div>
                    <div class="row br-benefit_item-container">
                        <div>
                            <div><i class="fa fa-anchor" aria-hidden="true"></i></div>
                            <div>
                                <h6>Размеры яхты</h6>
                                Длина: 19,90 метров</br>
                                Ширина: 4,7 метра</br>
                                Осадка: 3
                            </div>
                        </div>
                        <div>
                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                            <div>
                                <h6>Вместительность</h6>
                                Вместимость: 10 человек
                                Спальных мест: 10 (5 кают)
                            </div>
                        </div>

                        <div>
                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                            <div>
                                <h6>Кают-компания</h6>
                                10 мест, по центру яхты.</br>
                                Высота потолков: 190 см, в моторном отсеке под
                                каютой : 120 см.</br>
                                Два спуска на нижний уровень:в нос и корму.
                            </div>
                        </div>

                        <div>
                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                            <div>
                                <h6>Носовая часть</h6>
                                2 двухместные каюты.</br>
                                Каюта экипажа, VIP каюта на 2х. Носовой кубрик с 3 спальными местами.</br>
                                Расположен общий гальюн, душ и сушилка.
                            </div>
                        </div>
                        <div>
                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                            <div>
                                <h6>кормовая часть</h6>
                                Камбуз, мастер-каюта с отдельным душем, туалетом и стиральной
                                машиной, детская каюта с тремя спальными местами.
                            </div>
                        </div>
                        <div>
                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                            <div>
                                <h6>Кондиционер</h6>
                                В каждой каюте выход кондиционера, всего на яхте два, один работает на нос и
                                кают-компанию, второй на корму.
                            </div>
                        </div>
                        <div>
                            <div><i class="fa fa-anchor" aria-hidden="true"></i></div>
                            <div>
                                <h6>Электричество</h6>
                                В каютах 220 вольт.</br>
                                7 солнечных панелей на крыше спрейхуда общей мощностью 462вт</br>
                                ветро-генератор 350вт</br>
                                дизель генератор Vetus 5.2 Квт</br>
                                есть и 2 инвертора 350 вт и 1 Квт.
                            </div>
                        </div>

                        <div>
                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                            <div>
                                <h6>УДОБСТВО</h6>
                                Проектор, Wi-fi, В кают-компании установлена аудио-видео система Pioneer. Аудио
                                колонки, кроме внутреннего расположения, также дополнительно выведены в кокпит. В
                                мастер-каюте телевизор SONY.
                            </div>
                        </div>
                        <!--                        <div>-->
                        <!--                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>-->
                        <!--                            <div>-->
                        <!--                                <h6>Палуба и кокпит</h6>-->
                        <!--                                покрыты натуральным тиком.-->
                        <!---->
                        <!--                            </div>-->
                        <!--                        </div>-->
                        <!--                        <div>-->
                        <!--                            <div><i class="fa fa-anchor" aria-hidden="true"></i></div>-->
                        <!--                            <div>-->
                        <!--                                <h6>Страна регистрации</h6>-->
                        <!--                                Российская Федерация</br>-->
                        <!--                                Порт стоянки: Ялта-->
                        <!---->
                        <!--                            </div>-->
                        <!--                        </div>-->

                    </div>
                </div>
                <div class="col-md-4 col-sm-12 br-benefit_img">
                    <div class="slick_2 slick-img-suit">
                        <div>
                            <img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit1.jpg')" alt="">
                        </div>
                        <div>
                            <img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit2.jpg')" alt="">
                        </div>
                        <!--                        <div>          <img src="-->
                        <?php //echo get_template_directory_uri(); ?><!--/yacht/img/suit/suit3.jpg')" alt="">   </div>-->
                        <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit4.jpg')" alt="">
                        </div>
                        <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit5.jpg')" alt="">
                        </div>
                        <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit6.jpg')" alt="">
                        </div>
                        <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit7.jpg')" alt="">
                        </div>
                        <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit8.jpg')" alt="">
                        </div>
                        <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit9.jpg')" alt="">
                        </div>
                        <!--                        <div>          <img src="-->
                        <?php //echo get_template_directory_uri(); ?><!--/yacht/img/suit/suit10.jpg')" alt="">   </div>-->


                    </div>
                    <!--                    <img src="-->
                    <?php //echo get_template_directory_uri(); ?><!--/img/breeze/benefits-img.jpg')" alt="">-->

                    <div class="br-benefit_img_text">
                        Яхта построена под кругосветное плавание в разных погодных условиях поэтому на яхте есть
                        жидкостное отопление, в
                        каждой каюте радиатор с включаемыми вентиляторами, отопитель работает на дизельном топливе.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="item-text-box">
                <div class="title-block-dec">
                    <div class="subtitle">Meet our team</div>
                    <h2>Наша команда</h2>
                </div>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                </p>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="team-item">
                        <div class="team-item_img-box">
                            <div class="team-item_img-box_img">
                                <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/sailor_01-290x290.jpg"
                                     alt="">
                            </div>
                        </div>
                        <div class="team-item_name">
                            Nick
                            <div>капитан</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="team-item">
                        <div class="team-item_img-box">
                            <div class="team-item_img-box_img">
                                <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/sailor_01-290x290.jpg"
                                     alt="">
                            </div>
                        </div>
                        <div class="team-item_name">
                            Nick
                            <div>капитан</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="team-item">
                        <div class="team-item_img-box">
                            <div class="team-item_img-box_img">
                                <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/sailor_01-290x290.jpg"
                                     alt="">
                            </div>
                        </div>
                        <div class="team-item_name">
                            Nick
                            <div>капитан</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="price-section">
        <div class="container">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-8">
                    <div class="row clearfix">
                        <!--Pricing Column-->
                        <div class="pricing-column col-xl-8 col-lg-12 col-sm-12">
                            <div class="inner">
                                <div class="item-text-box">
                                    <div class="title-block-dec">
                                        <div class="subtitle">Travel with us</div>
                                        <h2>Цены</h2>
                                    </div>
                                    <p>
                                        Вы можете взять в аренду яхту от 2 часов или на несколько дней, и наша команда
                                        поможет составить для вас маршрут.<br>
                                    </p>
                                </div>
                                <div class="row clearfix">
                                    <!--Price Column-->
                                    <div class="price-column col-md-6 col-sm-12 wow fadeInUp animated"
                                         data-wow-delay="0ms"
                                         data-wow-duration="1500ms"
                                         style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
                                        <div class="price-block">
                                            <div class="inner-box">
                                                <div class="plan-header">
                                                    <h4 class="plan-title">1 час</h4>
                                                    <div class="subtitle">Стоимость аренды в час.

                                                    </div>
                                                    <div class="price">
                                                        <span class="sign">₽</span>
                                                        <span class="amount">12000</span>
                                                        <span class="cycle"></span>
                                                    </div>
                                                    <div class="best-title"><span> Special Offers</span></div>
                                                </div>

                                                <div class="plan-features">
                                                    <ul>
                                                        <li>от 2х часов</li>
                                                        <li>экипаж из 2х человек</li>
                                                        <li>Waterproof Glass</li>
                                                    </ul>
                                                </div>
                                                <div class="link-box">
                                                    <a href="yacht-tour-single.html"
                                                       class="theme-btn book-btn"><span>Book Now</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Price Column-->
                                    <div class="price-column col-md-6 col-sm-12 wow fadeInDown animated"
                                         data-wow-delay="0ms" data-wow-duration="1500ms"
                                         style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInDown;">
                                        <div class="price-block">
                                            <div class="inner-box">
                                                <div class="plan-header">
                                                    <h4 class="plan-title">1 день</h4>
                                                    <div class="subtitle"> На длительный срок цена договорная.</div>
                                                    <div class="price">
                                                        <span class="sign">₽</span>
                                                        <span class="amount">100000</span>
                                                        <span class="cycle"></span>
                                                    </div>
                                                    <div class="best-title"><span> Special Offers</span></div>
                                                </div>

                                                <div class="plan-features">
                                                    <ul>
                                                        <li>экипаж от 2х человек
                                                        </li>
                                                        <li>Seperate Instructor</li>
                                                        <li>Waterproof Glass</li>
                                                    </ul>
                                                </div>
                                                <div class="link-box">
                                                    <a href="yacht-tour-single.html"
                                                       class="theme-btn book-btn"><span>Book Now</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Image Column-->
                        <div class="image-column col-xl-4 col-lg-12 col-sm-12">
                            <div class="inner wow slideInLeft animated" data-wow-delay="0ms" data-wow-duration="1500ms"
                                 style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: slideInLeft;">
                                <img src="images/resource/featured-image-6.jpg" alt="" title="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>

<?php get_template_part('yacht/breeze-footer'); ?>
<?php //get_footer(); ?>