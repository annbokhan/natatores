<div class="active-servises">
    <div style="" class="mob-hide">
        <div class="service-block now-in-view item-one">
            <div class="inner-box">
                <div class="image-box">
                    <a href="services.html">
                        <img src="<?php echo get_template_directory_uri(); ?>/yacht/img/featured-image-1.jpg')"
                             alt=""> </a>
                </div>

                <div class="lower-box">
                    <div class="lower-content">
                        <div class="icon-box"><span class="flaticon-yacht-1"></span></div>
                        <div class="cat">Boarding</div>
                        <h4><a href="#services.html">Wake and Skim <br>Boarding</a></h4>
                        <div class="link-box">
                            <a href="services.html" class="default-link">
                                <span class="icon flaticon-logout"></span> <span class="link-text">More About Boarding</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="service-block now-in-view item-one">
            <div class="inner-box">
                <div class="image-box">
                    <a href="services.html"><img
                            src="<?php echo get_template_directory_uri(); ?>/yacht/img/featured-image-2.jpg')"
                            alt=""></a>
                </div>

                <div class="lower-box">
                    <div class="lower-content">
                        <div class="icon-box"><span class="flaticon-yacht-1"></span></div>
                        <div class="cat">Boarding</div>
                        <h4><a href="#services.html">Wake and Skim <br>Boarding</a></h4>
                        <div class="link-box">
                            <a href="services.html" class="default-link">
                                <span class="icon flaticon-logout"></span> <span class="link-text">More About Boarding</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="service-block now-in-view">
            <div class="inner-box">
                <div class="image-box">
                    <a href="services.html"><img
                            src="<?php echo get_template_directory_uri(); ?>/yacht/img/featured-image-3.jpg')"
                            alt=""></a>
                </div>

                <div class="lower-box">
                    <div class="lower-content">
                        <div class="icon-box"><span class="flaticon-yacht-1"></span></div>
                        <div class="cat">Boarding</div>
                        <h4><a href="#services.html">Wake and Skim <br>Boarding</a></h4>
                        <div class="link-box">
                            <a href="services.html" class="default-link">
                                <span class="icon flaticon-logout"></span> <span class="link-text">More About Boarding</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="item-text-box">
        <div class="title-block-dec">
            <div class="subtitle">What we do</div>
            <h2 style=" font-size: 24px;">Передвижной мобильный центр экстремальных видов спорта</h2>
        </div>
        <p>Яхта спроектирована экстрималами для таких же любителей активного отдыха и острых ощущений<br>
            Трехместный гидроцикл Sea-Doo Wake Pro 215 — это буксировщик вейкбордистов или воднолыжника.<br>
            Виндсерфинговая доска с парусом и мачтой, доски для вейка и для кайта, два набора экипировки для
            дайвинга.<br>

            Большой ассортимент водных буксируемых игрушек.<br>

            Наполнение ангара может быть индивидуальным, готовы принимать гостей со своим оборудованием.
        </p>
    </div>

</div>
