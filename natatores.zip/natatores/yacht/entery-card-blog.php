<?php if (wp_is_mobile()) { ?>

    <div class="slick_1">
        <div class="item-one">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap"> <img
                                src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                                alt="" class="newsPreview__image"></a>

                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                            <span class="cat-links">
                             </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>
                                Аренда Яхты
                            </h2>
                        </a>
                        <div class="newsList__text">
                            <!--                    --><?php //the_excerpt(); ?>
                            Вы можете взять в аренду на несколько часов или отправиться в долгое путешествие. А мы
                            составим маршрут учитывая все ваши желания. Выходим в море каждый день. И наш экипаж
                            позаботится чтобы всё прошло на уровне
                        </div>

                    </div>
                </article>
            </div>
        </div>
        <div class="item-one">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap"> <img
                                src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                                alt="" class="newsPreview__image"></a>

                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                            <span class="cat-links">
                             </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>Проведение мероприятий</h2>
                        </a>
                        <div class="newsList__text">
                            Идеальный способ провести незабываемый День Рождения, вечеринку с друзьями, романтическое
                            свидание, корпоратив, фотосессию
                        </div>

                    </div>
                </article>
            </div>
        </div>
        <div class="item-one">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap"> <img
                                src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                                alt="" class="newsPreview__image"></a>
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                            <span class="cat-links">
                             </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>Активный отдых</h2>
                        </a>
                        <div class="newsList__text">
                            Вейк борд, дайвинг, рыбалка...<br>Яхта спроектирована как передвижной мобильный центр
                            экстремальных видов спорта. 3.6 метра с кормы безжалостно отдано под экстремальные игрушки,
                            чтобы ярко провести выходные!
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>

<? } else { ?>
    <div class="row slick_9">
        <div class="col-md-4 col-sm-12 col-xs-12 item-one">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                             alt="" class="newsPreview__image">
                    </a>
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                                <span class="cat-links"></span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>
                                Аренда Яхты
                            </h2>
                        </a>
                        <div class="newsList__text">
                            Вы можете взять в аренду на несколько часов или отправиться в долгое путешествие. А мы
                            составим маршрут учитывая все ваши желания. Выходим в море каждый день. И наш экипаж
                            позаботится чтобы всё прошло на уровне
                        </div>
                    </div>
                </article>
            </div>

        </div>
        <div class="col-md-4 col-sm-12 col-xs-12 item-one">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                             alt="" class="newsPreview__image">
                    </a>
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                                <span class="cat-links"></span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>Проведение мероприятий</h2>
                        </a>
                        <div class="newsList__text">
                            Идеальный способ провести незабываемый День Рождения, вечеринку с друзьями, романтическое
                            свидание, корпоратив, фотосессию
                        </div>
                    </div>
                </article>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12 item-one ">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                             alt="" class="newsPreview__image">
                    </a>
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                                <span class="cat-links"></span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>Активный отдых</h2>
                        </a>
                        <div class="newsList__text">
                            Вейк борд, дайвинг, рыбалка...<br>Яхта задумывалась как передвижной мобильный центр
                            экстремальных видов спорта. 3.6 метра с кормы безжалостно отдано под экстремальные игрушки,
                            чтобы ярко провести выходные!
                        </div>
                    </div>
                </article>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12 item-one ">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap">
                        <img
                                src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                                alt="" class="newsPreview__image">
                    </a>
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                                <span class="cat-links">  </span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>Кинотеатр на яхте</h2>
                        </a>
                        <div class="newsList__text">
                            Магия кино на борту нашей парусной яхты, после красивого заката.
                            Просмотр любимых фильмов с дорогими сердцу людьми — это вечера, полные
                            эмоций. Полный эффект присутствия при просмотре "Пиратов карибского моря", "Аквамена", или
                            любых других ваших любимых фильмов.
                        </div>
                    </div>
                </article>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12 item-one">
            <div class="newsPreview">
                <article>
                    <a href="#" class="newsPreview__imageWrap">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/service_01-128x84.jpg"
                             alt="" class="newsPreview__image">
                    </a>
                    <div class="newsPreview__content">
                        <div class="newsPreview__info">
                            <div href="#" class="newsPreview__rubric">
                                <span class="cat-links"></span>
                            </div>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"
                           class="newsPreview__title">
                            <h2>Кухня от шеф повара</h2>
                        </a>
                        <div class="newsList__text">
                            На нашем борту шеф-повар приготовит и сервирует великолепный ужин из заранее
                            закупленных продуктов, а если вам повезет в рыбалке, то он прямо на борту покажет настоящий
                            мастер-класс по приготовлению улова!
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
<?php } ?>

<!---->
<!--<div>-->
<!--    <div class="topSection__slide newsPreview">-->
<!--        <a href="--><?php //the_permalink(); ?><!--" class="newsPreview__imageWrap">-->
<!--            --><?php //the_post_thumbnail('full', 'class=newsPreview__image'); ?>
<!--        </a>-->
<!---->
<!--        <div class="newsPreview__content">-->
<!--            <div class="newsPreview__info">-->
<!--                <div href="#" class="newsPreview__rubric">-->
<!--                    <span class="cat-links">--><?php //the_category(' ', '', ''); ?><!--</span>-->
<!--                </div>-->
<!--                                <time class="newsPreview__time" datetime=" --><?php //the_time('Y-m-d'); ?><!--">-->
<!--                                    --><?php //the_time('j M H:i'); ?>
<!--                                </time>-->
<!--                                <a href="#" class="newsPreview__author"> --><?php //the_author(); ?><!--</a>-->
<!--                <a href="--><?php //the_permalink() ?><!--#comments" class="newsPreview__comments">-->
<!--                    --><?php //comments_number('0', '1', '%'); ?>
<!--                </a>-->
<!--            </div>-->
<!--            <a href="--><?php //the_permalink(); ?><!--" class="newsPreview__title">-->
<!--                <h2>-->
<!--                                        <a href="--><?php //the_permalink(); ?><!--" title="-->
<!--                    --><?php //the_title_attribute(); ?><!--" rel="bookmark">-->
<!--                    --><?php //the_title(); ?>
<!--                                        </a>-->
<!--                </h2>-->
<!--            </a>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->