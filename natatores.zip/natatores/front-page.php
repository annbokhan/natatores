<?php
///**
// * Template Name: silver breeze front page
// */

get_header(); ?>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/ru_RU/sdk.js#xfbml=1&version=v10.0&appId=132704220559407&autoLogAppEvents=1" nonce="mWKIxdn1"></script>

<section class="vc_section vc_custom_1545783735033 services-section">
    <div class="ltx-overlay-divider"></div>
    <div class="container">
        <div class="item-text-box">
            <div class="title-block-dec">
                <div class="subtitle">What we do</div>
                <h2>Предлагаем для Вас</h2>
            </div>
            <p>Integer sagittis nisi nec tortor fermentum aliquet. Integer non neque tempor, porttitor lorem id,
                commodo
                nulla. Nullam sed ultricies erat, nec euismod metus. Morbi porttitor sapien vitae leo scelerisque
                consequat.</p>
        </div>
        <div class="item-box-card services-sc ">
            <?php get_template_part('yacht/entery-card-blog'); ?>
        </div>
</section>

<section class="about-club">
    <div class="container">
        <div class="item-text-box">
            <div class="title-block-dec">
                <div class="subtitle">About club</div>
                <h2>About yacht club</h2>
            </div>
        </div>
        <div class="counter-numbers">
            <div class="row">
                <div class="col-md-4 item-numbers">
                    <div class="a-number">5</div>
                    <h3>Стран</h3>
                    <p>
                        Integer sagittis nisi nec tortor fermentum aliquet. Integer non neque. Nullam sed
                        ultricies.</p>
                </div>
                <div class="col-md-4 item-numbers">
                    <div class="a-number">52000</div>
                    <h3>Морских миль</h3>
                    <p>Integer sagittis nisi nec tortor fermentum aliquet. Integer non neque. Nullam sed
                        ultricies.</p>
                </div>
                <div class="col-md-4 item-numbers">
                    <div class="a-number">1570</div>
                    <h3>Счастливых гостей</h3>
                    <p>возможно ещё одна интересная цифра</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="watch-video">
    <div class="container">
        <div class="video-box">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="item-text-box">
                        <div class="title-block-dec">
                            <div class="subtitle">Media</div>
                            <h2>Watch our video</h2>
                        </div>
                        <p>
                            Natatores – общее латинское название плавающих птиц. А ведь известно: как ты яхту
                            назовешь, так она и поплывет. С таким именем она не плывет – летит по волнам, расправляя
                            свои паруса-крылья. Птица, скользящая по волнам.<br><br>

                            И команда, путешествующая на яхте, ей под стать. Экстремальная команда Natatores
                            объединяет людей, которые не представляют свою жизнь без приключений, драйва и
                            адреналина. Это парашютисты, дайверы и яхтсмены в одном лице. Нам и неба мало, и море по
                            колено. Если ты любишь экстремальный спорт, путешествия, море и адреналин, тебе у нас
                            понравится!<br><br>

                            Стань членом команды Natatores, отрасти крылья!
                        </p>
                    </div>
                </div>
                <div class="col-md-8 col-sm-12 block-frame">

                    <div class="fb-page" data-href="https://www.facebook.com/EkstremalnaaKomandaNatatores/"
                         data-tabs="timeline" data-adapt-container-width="true" data-width="" data-height="" data-small-header="true"
                         data-hide-cover="false" data-show-facepile="true">
                        <blockquote cite="https://www.facebook.com/EkstremalnaaKomandaNatatores/"
                                    class="fb-xfbml-parse-ignore"><a
                                    href="https://www.facebook.com/EkstremalnaaKomandaNatatores/">Экспедиционная
                                яхта &quot;Natatores&quot;</a></blockquote>
                    </div>

                    <!--                        <iframe width="560" height="315" src="https://www.youtube.com/embed/TIx0rOtnVhk?controls=0"-->
                    <!--                                frameborder="0"-->
                    <!--                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"-->
                    <!--                                allowfullscreen class="video-frame"></iframe>-->
                </div>
            </div>
        </div>
    </div>
</section>

<section class="tour-yacht-list">
    <div class="container">
        <div class="item-text-box">
            <div class="title-block-dec">
                <div class="subtitle">Travel with us</div>
                <h2>Варианты маршрутов вдоль берега</h2>
            </div>
            <p>
                Морские экскурсии – шанс взглянуть на город по-новому, так как с моря выглядит совершенно иначе.<br>
                Для сравнения длительности и дальности поездки мы привели несколько примеров локаций.<br>
                Предлагаем выбрать маршрут, в любом направлении, на выбранное время. Все детали обсуждаются с
                капитаном.
            </p>
        </div>
        <div class="row">
            <?php get_template_part('yacht/breeze-card-tour'); ?>
        </div>
    </div>
</section>

<section class="br-benefit">
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-sm-12 br-benefit_item">
                <div class="item-text-box">
                    <div class="title-block-dec">
                        <div class="subtitle">Natatores</div>
                        <h2>О Яхте</h2>
                    </div>
                </div>
                <div class="row br-benefit_item-container">
                    <div>
                        <div><i class="fa fa-anchor" aria-hidden="true"></i></div>
                        <div>
                            <h6>Размеры яхты</h6>
                            Длина: 19,90 метров</br>
                            Ширина: 4,7 метра</br>
                            Осадка: 3
                        </div>
                    </div>
                    <div>
                        <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                        <div>
                            <h6>Вместительность</h6>
                            Вместимость: 10 человек
                            Спальных мест: 10 (5 кают)
                        </div>
                    </div>
                    <div>
                        <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                        <div>
                            <h6>Кают-компания</h6>
                            10 мест, по центру яхты.</br>
                            Высота потолков: 190 см, в моторном отсеке под
                            каютой : 120 см.</br>
                            Два спуска на нижний уровень:в нос и корму.
                        </div>
                    </div>
                    <div>
                        <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                        <div>
                            <h6>Носовая часть</h6>
                            2 двухместные каюты.</br>
                            Каюта экипажа, VIP каюта на 2х. Носовой кубрик с 3 спальными местами.</br>
                            Расположен общий гальюн, душ и сушилка.
                        </div>
                    </div>
                    <div>
                        <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                        <div>
                            <h6>кормовая часть</h6>
                            Камбуз, мастер-каюта с отдельным душем, туалетом и стиральной
                            машиной, детская каюта с тремя спальными местами.
                        </div>
                    </div>
                    <div>
                        <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                        <div>
                            <h6>Кондиционер</h6>
                            В каждой каюте выход кондиционера, всего на яхте два, один работает на нос и
                            кают-компанию, второй на корму.
                        </div>
                    </div>
                    <div>
                        <div><i class="fa fa-anchor" aria-hidden="true"></i></div>
                        <div>
                            <h6>Электричество</h6>
                            В каютах 220 вольт.</br>
                            7 солнечных панелей на крыше спрейхуда общей мощностью 462вт</br>
                            ветро-генератор 350вт</br>
                            дизель генератор Vetus 5.2 Квт</br>
                            есть и 2 инвертора 350 вт и 1 Квт.
                        </div>
                    </div>
                    <div>
                        <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>
                        <div>
                            <h6>УДОБСТВО</h6>
                            Проектор, Wi-fi, В кают-компании установлена аудио-видео система Pioneer. Аудио
                            колонки, кроме внутреннего расположения, также дополнительно выведены в кокпит. В
                            мастер-каюте телевизор SONY.
                        </div>
                    </div>
                    <!--                        <div>-->
                    <!--                            <div><i class="fa fa-life-ring" aria-hidden="true"></i></div>-->
                    <!--                            <div>-->
                    <!--                                <h6>Палуба и кокпит</h6>-->
                    <!--                                покрыты натуральным тиком.-->
                    <!---->
                    <!--                            </div>-->
                    <!--                        </div>-->
                    <!--                        <div>-->
                    <!--                            <div><i class="fa fa-anchor" aria-hidden="true"></i></div>-->
                    <!--                            <div>-->
                    <!--                                <h6>Страна регистрации</h6>-->
                    <!--                                Российская Федерация</br>-->
                    <!--                                Порт стоянки: Ялта-->
                    <!---->
                    <!--                            </div>-->
                    <!--                        </div>-->

                </div>
            </div>

            <div class="col-md-4 col-sm-12 br-benefit_img">
                <div class="slick_2 slick-img-suit">
                    <div>
                        <img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit1.jpg')" alt="">
                    </div>
                    <div>
                        <img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit2.jpg')" alt="">
                    </div>
                    <!--                        <div>          <img src="-->
                    <?php //echo get_template_directory_uri(); ?><!--/yacht/img/suit/suit3.jpg')" alt="">   </div>-->
                    <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit4.jpg')" alt="">
                    </div>
                    <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit5.jpg')" alt="">
                    </div>
                    <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit6.jpg')" alt="">
                    </div>
                    <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit7.jpg')" alt="">
                    </div>
                    <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit8.jpg')" alt="">
                    </div>
                    <div><img src="<?php echo get_template_directory_uri(); ?>/yacht/img/suit/suit9.jpg')" alt="">
                    </div>
                    <!--                        <div>          <img src="-->
                    <?php //echo get_template_directory_uri(); ?><!--/yacht/img/suit/suit10.jpg')" alt="">   </div>-->


                </div>
                <!--                    <img src="-->
                <?php //echo get_template_directory_uri(); ?><!--/img/breeze/benefits-img.jpg')" alt="">-->

                <div class="br-benefit_img_text">
                    Яхта построена под кругосветное плавание в разных погодных условиях поэтому на яхте есть
                    жидкостное отопление, в
                    каждой каюте радиатор с включаемыми вентиляторами, отопитель работает на дизельном топливе.
                </div>
            </div>
        </div>
    </div>
</section>

<section class="all-characteristics">
    <div class="container">
        <div class=" ">
            <div class="item-text-box">
                <div class="title-block-dec">
                    <div class="subtitle">Technical Characteristics</div>
                    <h2>Технические характеристики</h2>
                </div>
            </div>

            <div class="all-info">
                <h2 class="detail-name">Технические характеристики</h2>

                Двухмачтовый парусный КЭЧ</br>
                Длина: 19.9 м</br>
                Ширина: 4.7 м</br>
                Осадка: 3 м</br></br>

                Страна регистрации: Российская Федерация</br></br>

                Техническое устройство</br>
                Двигатель: 114 лс DEUTH</br></br>

                Подруливающее устройство: VETUS</br></br>

                Топливные баки: 4 бака общей вместимостью 1800 л</br></br>

                Водные баки: три бака общей вместимостью 560 л</br></br>

                <h2 class="detail-name">Конструкция корпуса</h2>

                Материал:</br>

                корпус — сталь</br>
                надстройка — алюминий</br>
                монтаж стали и алюминия выполнен с помощью би-металла по голландской технологии</br>
                Покраска: AWLGRIPP</br></br>

                Кокпит: центральный, место рулевого защищено стационарным спрейхудом из алюминия.</br></br>

                Палуба и кокпит покрыты натуральным тиком.

                <h2 class="detail-name">Описание кают</h2>

                Вход в яхту: дверь задрайка из алюминия.</br>

                Отделка яхты внутри: натуральное красное дерево, кожа.</br>

                Кают-компания на 10 посадочных мест, по центру яхты, под ней – моторный отсек. Высота
                потолков в
                кают-компании: 190 см, в моторном отсеке: 120 см. Из кают-компании два спуска на нижний
                уровень: в
                нос и
                корму.</br></br>

                В носовой части две двухместные классические яхтенные каюты с низким спальным местом. Одна
                из них —
                каюта экипажа, одна — VIP каюта на двух человек. Носовой кубрик с тремя спальными местами.
                Также в
                носовой части яхты расположен общий гальюн, душ и сушилка для непромоканцев и яхтенной
                обуви.</br></br>

                В кормовой части яхты находятся: камбуз, мастер-каюта с отдельным душем, туалетом и
                стиральной
                машиной,
                детская каюта с тремя спальными местами.</br></br>

                Итого мы имеем три каюты в носовой части на семерых гостей, каюту экипажа, в кормовой —
                мастер-каюту
                на
                двух человек и детскую на трех. Итого можно с относительным комфортом разместить 12 человек.
                Если
                среди
                них будет дети, то комфорт будет полным.

                <h2 class="detail-name">Палубное оборудование</h2>

                Две мачты производства компании SELDEN с закрутками в мачту:</br>

                бизань-мачта — электрическая</br>
                грот — ручной</br>
                Всего стационарно установлено 4 паруса:</br>

                генуя — 108 м</br>
                стаксель — 50 м</br>
                грот — 54 м</br>
                бизань — 22 м</br>
                Есть места для установки спинакера.</br></br>

                На попутных курсах ставим генакер площадью 158 м.</br></br>

                Управление парусами осуществляется с помощью 7 лебедок LEWMAR размером от 64 до 48. Одна из
                них
                электрическая: HARKEN 46.</br></br>

                Якорная лебедка: Vetus</br>

                Цепь: 13 мм, 150 м

                <h2 class="detail-name"> Навигационное оборудование</h2>

                два картплоттера FURUNO: один из них установлен в кают-компании + репитер FURUNO</br>
                AIS RAYMARINE</br>
                радар FURUNO 4 КВт</br>
                Также имеется две радиостанции Standart Horizon: стационарная и носимая.

                <h2 class="detail-name"> Спасательное оборудование</h2>
                Два плота ZODIAC в океанской комплектации на 6 и на 8 человек. Оба установлены на релингах с
                устройствами быстрого сброса.

                <h2 class="detail-name">Дополнительное оборудование</h2>

                Теперь «опции».</br>
                Яхта строилась под кругосветное плавание в разных погодных условиях, поэтому на яхте есть
                жидкостное
                отопление. В каждой каюте — радиатор с включаемыми вентиляторами.</br> Отопитель работает на
                дизельном
                топливе. Отдельный отопительный элемент (сушилка) расположен в общем туалете и работает на
                электричестве.</br></br>

                Также в каждой каюте есть выход кондиционера, всего их на яхте два, один работает на нос и
                кают-компанию, второй на корму. Все оборудование морское, специализированое.</br></br>

                Камбуз оснащен двухкомфорочной яхтенной газовой плитой с духовкой, двумя
                холодильниками.</br></br>

                Электричество в каждой каюте 220 вольт. Не остаться без света нам помогают: 7 солнечных
                панелей на
                крыше
                спрейхуда общей мощностью 462 Вт, ветрогенератор мощностью 350 Вт и дизель-генератор Vetus
                мощностью
                5.2
                КВт. Есть и 2 инвертора: 350 Вт и 1 КВт. В принципе, все оборудование яхты может работать
                только от
                солнечных панелей и ветрогенератора, дизель-генератор нужен только в трех случаях – если
                нужно
                включить
                стиральную машину, которая стоит в душевой мастер-каюты, включить кондиционеры или включить
                опреснитель
                на 70 литров пресной воды в час, который используется как основной.</br></br>

                В моторном отсеке расположен отдельный аварийный опреснитель с производительностью 5.6 л/ч,
                который
                работает как от 12 вольт (для него хватает солнечных панелей и ветрогенератора), так и в
                ручном
                режиме.</br></br>

                Также в кают-компании установлена аудио-видео система Pioneer. Аудио колонки, кроме
                внутреннего
                расположения, также дополнительно выведены в кокпит. В мастер-каюте есть отдельный телевизор
                SONY.</br></br>

                <h2 class="detail-name">Игрушки</h2>
                Ну и на сладкое: яхта задумывалась как передвижной мобильный центр экстремальных видов
                спорта. 3.6
                метра
                с кормы безжалостно отдано под экстремальные игрушки.</br></br>

                Корма имеет алюминиевую откидную платформу, которая в откинутом виде представляет из себя
                прекрасную
                площадку для купания. Откинутая платформа открывает доступ в кормовой ангар (доступ к нему
                есть
                также с
                палубы через люк).</br></br>

                Сейчас там стоит большой трехместный гидроцикл Sea-Doo Wake Pro 215 — это буксировщик
                вейкбордистов
                или
                воднолыжника.</br></br>

                Там же — виндсерфинговая доска с парусом и мачтой, доски для вейка и для кайта, два набора
                экипировки
                для дайвинга.</br></br>

                Большой ассортимент водных буксируемых игрушек.</br></br>

                Наполнение ангара может быть индивидуальным, готовы принимать гостей со своим оборудованием.
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="item-text-box">
            <div class="title-block-dec">
                <div class="subtitle">Meet our team</div>
                <h2>Наша команда</h2>
            </div>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            </p>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="team-item">
                    <div class="team-item_img-box">
                        <div class="team-item_img-box_img">
                            <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/sailor_01-290x290.jpg"
                                 alt="">
                        </div>
                    </div>
                    <div class="team-item_name">
                        Nick
                        <div>капитан</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="team-item">
                    <div class="team-item_img-box">
                        <div class="team-item_img-box_img">
                            <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/sailor_01-290x290.jpg"
                                 alt="">
                        </div>
                    </div>
                    <div class="team-item_name">
                        Nick
                        <div>капитан</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="team-item">
                    <div class="team-item_img-box">
                        <div class="team-item_img-box_img">
                            <img src="<?php echo get_template_directory_uri(); ?>/img/breeze/sailor_01-290x290.jpg"
                                 alt="">
                        </div>
                    </div>
                    <div class="team-item_name">
                        Nick
                        <div>капитан</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="price-section">
    <div class="container">
        <div class="row clearfix">
            <!--Pricing Column-->
            <div class="pricing-column">
                <div class="inner">
                    <div class="item-text-box">
                        <div class="title-block-dec">
                            <div class="subtitle">Travel with us</div>
                            <h2>Цены</h2>
                        </div>
                        <p>
                            Вы можете взять в аренду яхту от 2 часов или на несколько дней, и наша команда
                            поможет составить для вас маршрут.<br>
                        </p>
                    </div>
                    <div class="row clearfix">
                        <!--Price Column-->
                        <div class="price-column col-md-4 col-sm-12 wow fadeInUp animated"
                             data-wow-delay="0ms"
                             data-wow-duration="1500ms"
                             style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
                            <div class="price-block">
                                <div class="inner-box">
                                    <div class="plan-header">
                                        <h4 class="plan-title">1 час</h4>
                                        <div class="subtitle">Стоимость аренды в час.</div>
                                        <div class="price">
                                            <span class="sign">₽</span>
                                            <span class="amount">12000</span>
                                            <span class="cycle"></span>
                                        </div>
                                        <div class="best-title"><span> Special Offers</span></div>
                                    </div>
                                    <div class="plan-features">
                                        <ul>
                                            <li>от 2х часов</li>
                                            <li>экипаж из 2х человек</li>
                                            <li>Waterproof Glass</li>
                                        </ul>
                                    </div>
                                    <div class="link-box">
                                        <a href="yacht-tour-single.html"
                                           class="theme-btn book-btn"><span>Book Now</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Price Column-->
                        <div class="price-column col-md-4 col-sm-12 wow fadeInDown animated"
                             data-wow-delay="0ms" data-wow-duration="1500ms"
                             style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInDown;">
                            <div class="price-block">
                                <div class="inner-box">
                                    <div class="plan-header">
                                        <h4 class="plan-title">1 день</h4>
                                        <div class="subtitle"> На длительный срок цена договорная.</div>
                                        <div class="price">
                                            <span class="sign">₽</span>
                                            <span class="amount">100000</span>
                                            <span class="cycle"></span>
                                        </div>
                                        <div class="best-title"><span> Special Offers</span></div>
                                    </div>
                                    <div class="plan-features">
                                        <ul>
                                            <li>экипаж от 2х человек
                                            </li>
                                            <li>Seperate Instructor</li>
                                            <li>Waterproof Glass</li>
                                        </ul>
                                    </div>
                                    <div class="link-box">
                                        <a href="yacht-tour-single.html"
                                           class="theme-btn book-btn"><span>Book Now</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="price-column col-md-4 col-sm-12 wow fadeInDown animated"
                             data-wow-delay="0ms" data-wow-duration="1500ms"
                             style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInDown;">
                            <div class="price-block">
                                <div class="inner-box">
                                    <div class="plan-header">
                                        <h4 class="plan-title">1 неделя</h4>
                                        <div class="subtitle"> На длительный срок цена договорная.</div>
                                        <div class="price">
                                            <span class="sign">₽</span>
                                            <span class="amount">100000</span>
                                            <span class="cycle"></span>
                                        </div>
                                        <div class="best-title"><span> Special Offers</span></div>
                                    </div>
                                    <div class="plan-features">
                                        <ul>
                                            <li>экипаж от 2х человек
                                            </li>
                                            <li>Seperate Instructor</li>
                                            <li>Waterproof Glass</li>
                                        </ul>
                                    </div>
                                    <div class="link-box">
                                        <a href="yacht-tour-single.html"
                                           class="theme-btn book-btn"><span>Book Now</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--Image Column-->
            <div class="image-column ">
                <div class="inner wow slideInLeft animated" data-wow-delay="0ms" data-wow-duration="1500ms"
                     style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: slideInLeft;">
                    <img src="images/resource/featured-image-6.jpg" alt="" title="">
                </div>
            </div>
        </div>
    </div>
</section>

<section class="faq-box">
    <div class="container">
        <div class="item-text-box">
            <div class="title-block-dec">
                <div class="subtitle">Recomendation</div>
                <h2> Часто задаваемые вопросы</h2>
            </div>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            </p>
        </div>
        <h3>НА КАКОЙ СРОК Я МОГУ ВЗЯТЬ ЯХТУ В АРЕНДУ? </h3>
        <p>Вы можете выбрать любую продолжительность аренды — срок зависит только от доступности самой
            яхты.
            Обычно, в берут яхту в чартер от 3 часов и до нескольких недель. Наша яхта доступна для
            непродолжительного отдыха, можно использовать для проведения мероприятий. Также можете арендовать яхту
            на длительный срок и даже совершить путешествие вдоль всего Крыма.</p>
        <h3>КАК АРЕНДОВАТЬ ЯХТУ?</h3>
        <p>К вашим услугам наша команда консультантов по чартеру. Мы поможем вам выбрать подходящую
            дату,
            спланировать маршрут и организовать незабываемый отдых. О том, готова ли яхта на выбранне
            даты можно узнать, подав запрос на нашем сайте или связавшись напрямую с нами
            по организации чартера. Все контакты представлены на сайте</p>

        <h3>КАК ЗАКРЕПИТЬ ЗА СОБОЙ ЯХТУ?</h3>
        <p>Все чартеры подлежат бронированию по контракту. Как только мы подтвердим доступность яхты на
            выбранные даты, Вы получите Чартерное Соглашение и запрос на внесение депозита, который
            позволит
            закрепить яхту за Вами. В Чартерном Соглашении обозначены все условия, а также права и
            обязанности каждой из сторон. Депозит составляет 50% от полной суммы за аренду яхты.
            Оставшиеся
            50%, а также дополнительные расходы и НДС, плата за доставку или возврат яхты (если
            потребуется)
            и любые другие сборы взимаются за неделю до начала Вашего путешествия.</p>


        <h3>МОГУ ЛИ Я ОТМЕНИТЬ АРЕНДУ И СДЕЛАТЬ ВОЗВРАТ ОПЛАЧЕННОЙ СУММЫ?</h3>

        <p>В соответствии с правилами Средиземноморской Ассоциации Яхтенных Брокеров (MYBA), если Вы
            решите
            отменить чартер, то владелец яхты может удержать депозит или полную стоимость — это зависит
            от
            сроков, в которые Вы сделаете отмену. Если отмена чартера произведена после внесения
            депозита,
            но полная стоимость еще не была удержана, то владелец правомочен оставить за собой сумму
            депозита. Если отмена сделана уже после того, как Вы заплатили полную стоимость чартера, то
            владелец яхты удерживает всю сумму, но возвращает вам стоимость дополнительных расходов.
            Если Вы
            вынуждены отменить Ваше путешествие, проконсультируйтесь предварительно с консультантом
            —
            это позволит свести потери к минимуму (например, договориться с владельцем яхты об
            альтернативных датах чартера). Стоит помнить, что разные контракты могут содержать разные
            условия отмены.</p>


        <h3> МОГУ ЛИ Я ПОЛЬЗОВАТЬСЯ ДОПОЛНИТЕЛЬНЫМ ОБОРУДОВАНИЕМ? </h3>
        <p>Безусловно, вы можете использовать все возможности и пользоваться любым оборудованием,
            наслаждаясь яхтой, как собственной.</p>

        <h3> РАЗРЕШАЕТСЯ ЛИ ИСПОЛЬЗОВАТЬ ОБОРУДОВАНИЕ ДЛЯ ВОДНОГО СПОРТА И ДАЙВИНГА? </h3> </p>

        <p>Во многих странах вам необходимо иметь лицензию для использования определенного оборудования
            (водные лыжи, гидроциклы и другие устройства с механическим приводом). Помимо этого могут
            быть
            ограничения по возрасту. Для дайвинга Вам также понадобится лицензия PADI или
            эквивалентная ей. Если необходимых сертификатов у Вас нет, то мы с
            удовольствием найдём инструктора по дайвингу, который будет сопровождать Вас в течение
            путешествия.</p>
        <h3>
            РАЗРЕШЕНО ЛИ КУРИТЬ НА БОРТУ ЯХТЫ?</h3>
        <p>Курение запрещено на борту большинства яхт. Из соображений безопасности курение
            запрещено в каютах и других помещениях всех яхт без исключения.</p>
        <h3>СКОЛЬКО ОСТАВИТЬ ЧАЕВЫХ ЭКИПАЖУ?</h3>

        <p>Вознаграждения команде яхты не являются обязательными, но обычно оставляют от 10% и до 20% от
            стоимости чартера (на Ваше усмотрение и в зависимости от степени удовлетворения сервисом).
            Лучший способ не оставить никого в обиде — передать чаевые капитану яхты или чартерному
            консультанту, а они, в свою очередь, поделят сумму между членами экипажа.</p>
        <h3>СКОЛЬКО ГОСТЕЙ РАЗРЕШЕНО ПРИГЛАСИТЬ НА БОРТ ЯХТЫ?</h3>
        <p>Количество гостей на яхте обусловлено ее размерами и числом спальных мест. Максимальное
            количество гостей для путешествия на яхте — 12 человек. Количество гостей на борту
            регулируется
            размером яхты и правилами безопасности на яхте.
            Уточните все детали у консультанта.</p>
        <h3> МОГУ ЛИ Я БЫТЬ УВЕРЕН, ЧТО НАЙДУ НА БОРТУ ВСЕ НЕОБХОДИМОЕ ДЛЯ ПУТЕШЕСТВИЯ (ЕДА,
            АЛКОГОЛЬ,..)?</h3>

        <p>Мы учитываем каждую деталь. За несколько дней до начала путешествия с Вами свяжется
            консультант и
            попросит заполнить подробную анкету с вопросами по Вашим пожеланиям и особым
            требованиям. Диетические предпочтения, особенности здоровья, любимые развлечения, виды
            спорта и
            отдыха — мы уточним все детали, чтобы сделать Ваше пребывание на яхте незабываемым.</p>
        <h3>
            КАК ОРГАНИЗОВАТЬ ДОПОЛНИТЕЛЬНЫЙ ДОСУГ (ЭКСКУРСИИ, ОСМОТР ДОСТОПРИМЕЧАТЕЛЬНОСТЕЙ,
            БРОНИРОВАНИЕ
            БИЛЕТОВ В ТЕАТРЫ И СТОЛИКИ В РЕСТОРАНАХ)? </h3>
        <p>Сообщите обо всех своих пожеланиях Вашему чартерному консультанту — вместе с капитаном и
            экипажем
            мы организуем любой дополнительный досуг и развлечения, которые Вы пожелаете.</p>
        <h3> МОЖНО ЛИ ВЫБРАТЬ, В КАКОЙ ДЕНЬ НЕДЕЛИ НАЧНЕТСЯ ЧАРТЕР?</h3>
        <p>Да, вы можете выбрать день начала чартера при условии что яхта свободна на выбранную вами
            дату.</p>
        <h3>КАК РАССЧИТАТЬ ЧАРТЕРНЫЙ ТАРИФ?</h3>
        <p>Тарифы рассчитываются по дням. Если чартер продолжается более недели, то общая стоимость
            чартера за неделю делится на семь и умножается на количество дней чартера. Если чартер
            продолжается менее недели, то общая стоимость чартера делится на шесть и умножается на
            количество дней чартера. Чартер яхты начинается в 10:00 первого дня и заканчивается в 12:00
            последнего дня. Также распространяются тарифы высокого сезона, которые действуют в
            течение наиболее популярных для аренды яхты периодов, и низкие сезонные тарифы, которые
            действуют
            все остальное время.</p>
        <h3>ЧТО ВХОДИТ В ЧАРТЕРНЫЙ ТАРИФ?</h3>
        <p>Чартерные тарифы включают оплату аренды яхты, услуг экипажа и всего необходимого
            оборудования,
            надлежащим образом застрахованного от морских рисков. Тарифы не включают НДС, затраты на
            продовольствие, топливо, электронные средства связи, сборы за проезд по каналам, портовые
            сборы,
            местные налоги и налоги, взимаемые конкретным портом или гаванью. За посадку на яхту и/или
            высадку с яхты в порту, который не является портом регистрации, взымаются сборы за
            доставку/возврат яхты.</p>
        <h3>МОЖНО ЛИ ВЫБРАТЬ МАРШРУТ ПУТЕШЕСТВИЯ?</h3>
        <p>Сообщите своему консультанту по чартеру, какие места вы хотели бы посетить. Яхта, как
            правило,
            находятся в определенном портк, но также может ходить по более широким
            акваториям.
            Окончательный маршрут вашего путешествия и количество заходов в порты на маршруте будут
            зависеть
            от скорости яхты, погодных условий и наличия свободных причалов в конкретной марине. Вход в
            порты некоторых стран может быть закрыт для яхт с флагом определенного государства.
            Пожалуйста,
            убедитесь в том, что вы получили визы всех государств, которые вы намерены посетить в ходе
            вашего путешествия. Также вы должны иметь в виду, что за посадку на яхту и/или высадку с
            яхты в
            порту, который не является портом приписки, взымаются сборы за доставку/возврат яхты.</p>

    </div>
</section>


<?php //get_template_part('yacht/breeze-footer'); ?>
<?php get_footer(); ?>