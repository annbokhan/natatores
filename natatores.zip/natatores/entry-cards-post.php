<!--<article id="post---><?php //the_ID(); ?><!--" --><?php //post_class(); ?><!-->
<!--    <header>-->
<!--        --><?php //if (is_singular()) {
//            echo '<h1 class="entry-title">';
//        } else {
//            echo '<h2 class="entry-title">';
//        } ?><!--<a href="--><?php //the_permalink(); ?><!--" title="--><?php //the_title_attribute(); ?><!--"-->
<!--               rel="bookmark">--><?php //the_title(); ?><!--</a>--><?php //if (is_singular()) {
//            echo '</h1>';
//        } else {
//            echo '</h2>';
//        } ?><!-- --><?php //edit_post_link(); ?>
<!--        --><?php //if (!is_search()) get_template_part('entry', 'meta'); ?>
<!--    </header>-->
<!--    --><?php //get_template_part('entry', (is_archive() || is_search() ? 'summary' : 'content')); ?>
<!--    --><?php //if (!is_search()) get_template_part('entry-footer'); ?>
<!--</article>-->


            <div class="col-md-3 col-sm-3 col-xs-12">
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                <div class="card mb-4 shadow-sm">
                    <header>
                        <div class="img-post">
                            <?php if (has_post_thumbnail()) {the_post_thumbnail();	} ?>
                        </div>
                    </header>

                    <div class="card-body">
                        <?php if (is_singular()) {
                            echo '<h1 class="entry-title">';
                        } else {
                            echo '<h2 class="entry-title">';
                        } ?><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"
                               rel="bookmark"><?php the_title(); ?></a><?php if (is_singular()) {
                            echo '</h1>';
                        } else {
                            echo '</h2>';
                        } ?> <?php edit_post_link(); ?>
<!--                        <p class="card-text">-->
<!--                            --><?php //get_template_part('entry', (is_archive() || is_search() ? 'summary' : 'content')); ?>
<!---->
<!--                        </p>-->
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
<!--                                <button type="button" class="btn btn-sm btn-outline-secondary">-->
<!--                                    <a href="--><?php //the_permalink(); ?><!--" title="--><?php //the_title_attribute(); ?><!--"-->
<!--                                            rel="bookmark">Читать</a>-->
<!--                                </button>-->
                                <!--                                <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>-->
                            </div>
<!--                            <small class="text-muted">9 mins</small>-->
                        </div>
                    </div>
                </div>
                </article>

            </div>
