<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>"/>
    <meta name="viewport" content="width=device-width"/>
    <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_uri(); ?>"/>

    <!--    <link href="--><?php //echo get_template_directory_uri(); ?><!--/theme.css" rel="stylesheet">-->

    <link href="<?php echo get_template_directory_uri(); ?>/font/css/eka-font.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/font/breeze/fonts.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/yacht/fonts/fontello-yacht-ico.css" rel="stylesheet">
    <!--    <link href="-->
     <link href="<?php echo get_template_directory_uri(); ?>/font/all-ico.css" rel="stylesheet">
    <!--    <link href="-->
     <link href="<?php echo get_template_directory_uri(); ?>/assets/css/animate.css" rel="stylesheet">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
          integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css"
          integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/assets/slick/slick.css"/>
    <link rel="stylesheet" type="text/css"
          href="<?php echo get_template_directory_uri(); ?>/assets/slick/slick-theme.css"/>

    <!--    <link href="--><?php //echo get_template_directory_uri(); ?><!--/theme-eka2.css" rel="stylesheet">-->


    <?php if (is_page(115)) { ?>

        <link href="<?php echo get_template_directory_uri(); ?>/rental-style.css" rel="stylesheet">
    <?php } else { ?>
        <link href="<?php echo get_template_directory_uri(); ?>/breeze-style.css" rel="stylesheet">
    <?php } ?>

    <!--    --><?php //if (is_page(110)) { ?>
    <!--        <link href="-->
    <?php //echo get_template_directory_uri(); ?><!--/parallax.css" rel="stylesheet">--><?php //} ?>
    <link href="https://fonts.googleapis.com/css?family=Philosopher" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora|Salsa|Oranienbaum|M+PLUS+1p|Poiret+One|Prata&display=swap"
          rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
          integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> class="text-center">
<header>
    <?php if (is_page(45)) { ?>
 <!--header breeze yacht-->
    <?php } elseif (is_page(112)) { ?>
        <div class="head-block gradient-overlay-half-dark-v3 bg-img-hero eltd-slider"
             style="background: url('<?php echo get_template_directory_uri(); ?>/img/breeze/SLIDE_01.jpg')">
            <!-- Main Content -->
            <div class="d-lg-flex align-items-lg-center">
                <div class="container space-2 space-0--lg mt-lg-8">
                    <div class="row justify-content-lg-between align-items-lg-center">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-sx-12 mb-lg-0 title-box-text">
                            <h3 class="subtitle wow fadeInUp" data-wow-offset="100" style="visibility: visible; animation-name: fadeInUp;">
                                Экспедиционная яхта
                            </h3>
                            <div class="text-box-head">
                                <h1 class="display-4 font-size-48--md-down text-white mb-0 fadeInUp wow"
                                    data-wow-offset="100" data-wow-delay="0.4s"
                                    style="visibility: visible; animation-name: fadeInUp;"></h1>
                                <span class="d-block text-white text-uppercase mb-2 fadeInUp wow" data-wow-offset="100"
                                      style="visibility: visible; animation-name: fadeInUp;" data-wow-delay="0.8s">
                                    Natatores
							  </span>
                                <p class="top-name-p">
                                    Мы рады приветствовать Вас на борту!
                                </p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    <?php } elseif (is_page(115)) { ?>
        <div class="head-block gradient-overlay-half-dark-v3 bg-img-hero eltd-slider"
             style="background: url('<?php echo get_template_directory_uri(); ?>/img/rental/bg-home-5.jpg')">
            <!-- Main Content -->
            <div class="d-lg-flex align-items-lg-center">
                <div class="container space-2 space-0--lg mt-lg-8">
                    <div class="row justify-content-lg-between align-items-lg-center">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-sx-12 mb-lg-0 title-box-text">
                            <!-- Title --><h3 class="subtitle wow fadeInUp" data-wow-offset="100"
                                              style="visibility: visible; animation-name: fadeInUp;">Экспедиционная яхта</h3>
                            <div class="text-box-head">
                                <h1 class="display-4 font-size-48--md-down text-white mb-0 fadeInUp wow"
                                    data-wow-offset="100" data-wow-delay="0.4s"
                                    style="visibility: visible; animation-name: fadeInUp;"></h1>
                                <span class="d-block text-white text-uppercase mb-2 fadeInUp wow" data-wow-offset="100"
                                      style="visibility: visible; animation-name: fadeInUp;" data-wow-delay="0.8s">

                                    Natatores
							  </span>
                                <p class="top-name-p">
                                    Мы рады приветствовать тебя на борту яхты Natatores!
                                </p>
                            </div>

                            <a href="#" class="btn-more fadeInUp wow" data-wow-offset="100"
                               style="visibility: visible; animation-name: fadeInUp;" data-wow-delay="1s">
                                Арендовать
                                <span class="fa fa-angle-right align-middle ml-2"></span>
                            </a>
                            <a href="#" class="btn-more fadeInUp wow" data-wow-offset="100"
                               style="visibility: visible; animation-name: fadeInUp;" data-wow-delay="1s">
                                Купить
                                <span class="fa fa-angle-right align-middle ml-2"></span>
                            </a>
                            <!-- End Title -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php } else { ?>

        <div class="head-block  bg-img-hero gradient-overlay-half-dark-v3 pages-head-top  eltd-slider">
            <!-- Main Content -->
            <div class="d-lg-flex align-items-lg-center ">
                <div class="container space-2 space-0--lg mt-lg-8">
                    <div class="row justify-content-lg-between align-items-lg-center">
                        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <div id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="margin: 0 auto;">
                                <div class=" title-box-text">

                                    <h1 class="entry-title"><?php the_title(); ?></h1>
                                </div>
                            </div>
                        <?php endwhile; endif; ?>
                    </div>
                </div>
            </div>
        </div>

    <?php } ?>
    <!-- End Main Content -->
    <div class="ltx-overlay-divider"></div>
</header>

<nav class="navbar navbar-dark navbar-expand-md fixed-top bg-faded" id="nav-top-fixed" data-toggle="affix">
    <div class="container">
      <div class="soc-nav">
          <div class="align-default soc-netw">
              <ul class="social-big icon-weight-bold" id="like_sc_header_502828980">
                  <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="https://www.instagram.com/abra_kadabra" target="_blank"><i class="fab fa-instagram"></i></a></li>
                  <li><a href="#"><i class="fab fa-youtube"></i></a></li>
               </ul>
          </div>
          <a class="navbar-brand" id="logo-nav" href="/">
           </a>
          <a href="tel:+70234565861" class="soc_phone">0(800) 890-90-609</a>
      </div>

        <button class="navbar-toggler hidden-sm-up pull-xs-right" type="button" data-toggle="collapse"
                data-target="#collapsingNavbar">
            ☰
        </button>
        <div class="collapse navbar-collapse main-nav" id="collapsingNavbar">
            <?php wp_nav_menu(array('theme_location' => 'main-menu')); ?>

        </div>
    </div>
</nav>

