$(document).ready(function() {
    var toggleAffix = function(affixElement, scrollElement, wrapper) {
        var height = affixElement.outerHeight(),
            top = wrapper.offset().top;
        if (scrollElement.scrollTop() >= (top - height)){
            // wrapper.height(height);
            affixElement.addClass("affix");
        }
        else {
            affixElement.removeClass("affix");
        }
    };
    $('[data-toggle="affix"]').each(function() {
        var ele = $(this),
            wrapper = $('<div></div>');
        ele.before(wrapper);
        $(window).on('scroll resize', function() {
            toggleAffix(ele, $(this), wrapper);
        });
        // init
        toggleAffix(ele, $(window), wrapper);
    });
	});
           

// $(document).ready(function () {
//     $("img.lazyload").lazyload();
//
//     // $('.screenshot-slider').bxSlider({
//     //     slideWidth: 320,
//     //     slideMargin: 10,
//     //     maxSlides: 3,
//     //     minSlides: 3,
//     //     moveSlides: 1,
//     //     controls: true
//     // });
//
//
//     //accordion text script
//     var textBox = $('.js-accordion-text');
//     textBox.each(function () {
//         var boxHeight = $(this).attr('data-height');
//         $(this).css('height', boxHeight + 'px');
//     });
//
//     $('body').on('click', '.js-accordion-text-btn', function () {
//         var heightSize = $(this).parent('.js-accordion-text').attr('data-height');
//         var curHeight = $(this).parent('.js-accordion-text').height(); // Get Default Height
//         var autoHeight = $(this).parent('.js-accordion-text').css('height', 'auto').height() + 50;// Get Auto Height
//         if (heightSize >= autoHeight) {
//             $(this).hide();
//         }
//         if (!$(this).hasClass('active')) {
//             $(this).parent('.js-accordion-text').height(curHeight); // Reset to Default Height
//             $(this).parent('.js-accordion-text').stop().animate({height: autoHeight}, 300);
//             $(this).addClass('active');
//             $(this).html('Скрыть');
//         } else {
//             $(this).removeClass('active');
//             $(this).html('Читать все');
//             $(this).parent('.js-accordion-text').animate({height: heightSize + "px"}, 200);
//         }
//     });
// });


const icons = document.querySelectorAll('.icon');
icons.forEach(icon => {
    icon.addEventListener('click', (event) => {
        icon.classList.toggle("open");
    });
});

$('.icMenu').click(function () {
    $('.on-header-menu').toggleClass('active');
});

$(".read-more").on("click", function () {
    // declare text for read more label
    var text_more;
    // declare target collapsible content
    var content_collapse = $(this).data("target");
    // declare text for close label
    var text_close = $("[data-collapse=" + content_collapse + "]").data("text-close");

    // if content is not collapsed
    if (!$(this).hasClass('collapse-open')) {
        $(this).data("text-more", $(this).html());
        text_more = $(this).data("text-more");
        $(this).addClass('collapse-open');
        $(this).html(text_close);
        $("[data-collapse=" + content_collapse + "]").slideDown(300);
    } else {
        // if content is collapsed
        text_more = $(this).data("text-more");
        $(this).html(text_more);
        $(this).removeClass('collapse-open');
        $("[data-collapse=" + content_collapse + "]").slideUp(300);
    }
});

$(document).ready(function() {
   var scrolling = false;
   $(window).scroll(function() {
       if (($(window).scrollTop()) >= 40) {
         if (!scrolling){
           $('#header').addClass("op");
           scrolling = true;
         }
       } else {
           $('#header').removeClass("op");
       scrolling=false;
       }
   });
});

//
// $(document).ready(function () {
//     $('.readmorebox').each(function () {
//         var trimLength = 300;
//         var trimMargin = 1.2; // don't trim just a couple of words
//         if ($(this).text().length > (trimLength * trimMargin)) {
//             var text = $(this).text();
//             var trimPoint = $(this).text().indexOf(" ", trimLength);
//             var newContent = text.substring(0, trimPoint) + '<span class="read-more">' + text.substring(trimPoint) + '</span><span class="toggle">... <a href="#"></a></span>';
//             $(this).html(newContent);
//         }
//     });
//     $('.toggle a').click(function (e) {
//         e.preventDefault();
//         var para = $(this).closest('.readmorebox');
//         var initialHeight = $(this).closest('.readmorebox').innerHeight();
//         para.find('.read-more').show();
//         para.find('.toggle').hide();
//         var newHeight = para.innerHeight();
//         para.css('max-height', initialHeight + 'px');
//         para.animate({maxHeight: newHeight}, 300, function () {
//             para.css('max-height', 'none');
//         });
//     });
// });

   $('a[href^="/#"]').click(function(){
        var target = $(this).attr('href');
        $('html, body').animate({scrollTop: $(target).offset().top - 100}, 500);
        return false;
    });
