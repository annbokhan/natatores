<?php get_header(); ?>
    <section id="content" role="main" class="category-page-top">
        <div class="container">


            <!--        <header class="header">-->
            <h1 class="entry-title">
                <!--                --><?php //_e('Category Archives: ', 'blankslate'); ?>

                <?php single_cat_title(); ?></h1>
            <div class="bt_bb_separator bt_bb_border_style_arrow"></div>

            <!--        </header>-->
        </div>
        <img src="<?php echo get_template_directory_uri(); ?>/img/purple_top_divider.png" alt=""
             class="img-bg-section-bottom">

    </section>

    <section class="category-cnt-block">
        <div class="container">
            <?php if ('' != category_description()) echo apply_filters('archive_meta', '<div class="archive-meta">' . category_description() . '</div>'); ?>


            <section class="category-cnt-block">
                <div class="container">
                    <div class="row">

                        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <?php get_template_part('entry-cards-post'); ?>
                        <?php endwhile; endif; ?>

                    </div>

                </div>
            </section>



            <?php get_template_part('nav', 'below'); ?>

        </div>

    </section>
<?php
//if (is_category(2)) {
//    include('servises.php');
//}
//?>
    <!--<section>-->
    <!--    <div class="container">-->
    <!--    </div>-->
    <!--</section>-->
<?php //get_sidebar(); ?>

    <!--    <img src="--><?php //echo get_template_directory_uri()?><!--/img/purple_light_top_divider.png" alt="" class="card-img-bottom">-->

<?php get_footer(); ?>